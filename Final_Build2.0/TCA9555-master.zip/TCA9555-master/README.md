TCA9555
=======

TCA9555 Arduino Library

An Arduino Library for 16-bit I2C I/O expander TCA9555. Please refer to <a href="http://www.kerrywong.com/2011/03/05/tca9555-library-for-arduino/">TCA9555 Library for Arduino</a> for more details.
